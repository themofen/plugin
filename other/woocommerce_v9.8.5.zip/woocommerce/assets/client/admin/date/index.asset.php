<?php return array('dependencies' => array('lodash', 'moment', 'wp-i18n'), 'version' => '5c176087d214d33b1209');
